package com.example.grisolet1.Core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.grisolet1.Activites.MainActivity;
import com.example.grisolet1.Model.Player;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;

import org.checkerframework.checker.units.qual.A;

import java.util.ArrayList;

public class MainActivityInteractor implements MainActivityContract.Ineractor{

    private MainActivityContract.onOperationListener mListener;
    private ArrayList<Player>players = new ArrayList<>();

    public MainActivityInteractor(MainActivityContract.onOperationListener mListener) {
        this.mListener = mListener;
    }

    @Override
    public void performCreatePlayer (DatabaseReference reference, Player player) {

        mListener.onStart();

        reference.child(player.getKey()).setValue(player).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    mListener.onSuccess();
                    mListener.onEnd();
                }
                else
                {
                    mListener.onFailure();
                    mListener.onEnd();
                }
            }
        });
    }

    @Override
    public void performReadPlayers(DatabaseReference reference) {
        reference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Player player = snapshot.getValue(Player.class);
                players.add(player);
                mListener.onRead(players);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Player player = snapshot.getValue(Player.class);
                mListener.onUpdate(player);
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                Player player = snapshot.getValue(Player.class);
                mListener.onDelete(player);
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public void performUpdatePlayer(DatabaseReference reference, Player player) {
        mListener.onStart();
        reference.child(player.getKey()).setValue(player).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    mListener.onEnd();
                }
                else
                {
                    mListener.onEnd();
                }
            }
        });

    }

    @Override
    public void performDeletePlayer(DatabaseReference reference, Player player) {
        mListener.onStart();
        reference.child(player.getKey()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
               if(task.isSuccessful())
               {
                    mListener.onEnd();
               }
               else
               {
                   mListener.onEnd();
               }
            }
        });
    }
}
