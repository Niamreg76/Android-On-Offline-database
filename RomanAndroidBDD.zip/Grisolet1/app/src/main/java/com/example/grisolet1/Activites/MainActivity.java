package com.example.grisolet1.Activites;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.grisolet1.Core.MainActivityContract;
import com.example.grisolet1.Core.MainActivityPresenter;
import com.example.grisolet1.Model.Player;
import com.example.grisolet1.R;
import com.example.grisolet1.Utils.Config;
import com.example.grisolet1.Utils.CreatePlayerDialog;
import com.example.grisolet1.Utils.RecyclerViewAdapter;
import com.example.grisolet1.Utils.UpdatePlayerDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.ArrayList;

//import kotlin.random.jdk8.PlatformThreadLocalRandom;


public class MainActivity extends AppCompatActivity implements CreatePlayerDialog.createPlayerDialogListener, MainActivityContract.View, UpdatePlayerDialog.UpdatePlayerDialogListener, RecyclerViewAdapter.onPlayerListener {

    public MainActivityPresenter mPresenter;
    public ProgressBar mProgressbar;
    public DatabaseReference mReference;
    public RecyclerView mRecyclerView;
    public RecyclerViewAdapter recyclerViewAdapter;
    public ArrayList<Player> mPlayerList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Toolbar toolbar = findviewbyid(R.id.toolbar);
        mProgressbar = (ProgressBar)findViewById(R.id.progressBar);
        mRecyclerView = (RecyclerView)findViewById(R.id.recyclerView);

        mReference = FirebaseDatabase.getInstance().getReference().child(Config.USER_NODE);

        mPresenter = new MainActivityPresenter(this);
        mPresenter.readPlayers(mReference);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });


//        FirebaseDatabase database = FirebaseDatabase.getInstance();
  //      DatabaseReference myRef = database.getReference("message");
    //    DatabaseReference myRef1 = database.getReference("message2");
      //  DatabaseReference myRef2 = database.getReference("offline");

//        FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
//                .setCacheSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
//                .setPersistenceEnabled(true)
//                .build();
//        db.setFirestoreSettings(settings);

//        myRef.setValue("HelloBro");
  //      myRef1.setValue("YOOO1OO");
    //    myRef2.setValue("retest du 31/01/2023");

    }

    private void openDialog() {
        CreatePlayerDialog createPlayerDialog = new CreatePlayerDialog();
        createPlayerDialog.show(getSupportFragmentManager(), "create dialog");
    }

    @Override
    public void savePlayer(Player player) {
        //Toast.makeText(MainActivity.this, ""+player.getName(), Toast.LENGTH_SHORT).show();
        String key = mReference.push().getKey();
        Player newPlayer = new Player(player.getName(), player.getAge(), player.getPosition(), key);
        mPresenter.createNewPlayer(mReference, newPlayer);

    }

    @Override
    public void onCreatePlayerSuccessful() {
        Toast.makeText(MainActivity.this, "Nouveau joueur crée", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCreatePlayerFailure() {
        Toast.makeText(MainActivity.this, "Erreur", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProcessStart() {
        mProgressbar.setVisibility(View.VISIBLE);
    }

    @Override
    public void onProcessEnd() {
        mProgressbar.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onPlayerRead(ArrayList<Player> players) {

        this.mPlayerList = players;
        recyclerViewAdapter = new RecyclerViewAdapter(players, this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this );
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(recyclerViewAdapter);
    }

    @Override
    public void onPlayerUpdate(Player player) {
        int index = getIndex(player);
        mPlayerList.set(index, player);
        recyclerViewAdapter.notifyItemChanged(index);
    }

    @Override
    public void onPlayerDelete(Player player) {
        int index = getIndex(player);
        mPlayerList.remove(index);
        recyclerViewAdapter.notifyItemRemoved(index);

        Toast.makeText(MainActivity.this,"Delete Player "+player.getName(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void updatePlayer(Player player) {
        mPresenter.updatePlayer(mReference, player);
    }

    @Override
    public void onPlayerUpdateClick(int position) {
        Player player = mPlayerList.get(position);
        UpdatePlayerDialog updatePlayerDialog = new UpdatePlayerDialog(player);
        updatePlayerDialog.show(getSupportFragmentManager(), "update dialog");
    }

    @Override
    public void onPlayerDeleteClick(int position) {
        Player player = mPlayerList.get(position);
        mPresenter.deletePlayer(mReference, player);

    }

    public int getIndex(Player player)
    {
        int index = 0;
        for (Player countPlayer: mPlayerList)
        {
            if(countPlayer.getKey().trim().equals(player.getKey()))
            {
                break;
            }
            index++;
        }
        return index;
    }

}