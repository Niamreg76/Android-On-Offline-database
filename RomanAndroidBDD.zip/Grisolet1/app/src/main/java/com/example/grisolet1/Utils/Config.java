package com.example.grisolet1.Utils;

public class Config {
    public static String USER_NODE = "User";
}
